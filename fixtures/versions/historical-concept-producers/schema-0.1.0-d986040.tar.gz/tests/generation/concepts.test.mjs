import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { computeDesignVersionHash } from "../../src/contracts/creative/v1.mjs";
import { canonicalHash } from "../../src/contracts/validation.mjs";
import { METERING_PROPOSAL_VERSION } from "../../src/contracts/metering.mjs";
import { hashArtifactBytes } from "../../src/storage/content-addressed.mjs";
import {
  CREATIVE_CONCEPT_PROPOSAL,
  applyCreativeConceptEvent,
  createCreativeConceptBatchProposal,
  inspectCreativeConceptImageBytes,
  inspectCreativeConceptReferenceBytes,
  replayCreativeConceptBatch,
} from "../../src/generation/concepts.mjs";
import {
  FIXTURE_NOW,
  conceptProposalInput,
  conceptReferenceBytes,
} from "../../fixtures/generation/concept-proposal.mjs";
import { corruptPngCrc } from "../../fixtures/models/png.mjs";

const HASH = (value) => `sha256:${createHash("sha256").update(value).digest("hex")}`;
let eventSequence = 0;

function expectCode(code, callback) {
  assert.throws(callback, (error) => error?.code === code, `expected ${code}`);
}

function makeAttempt(batch, slot, suffix) {
  return {
    schema_version: METERING_PROPOSAL_VERSION,
    logical_operation_id: slot.logical_operation_id,
    billable_attempt_id: `billable-${slot.ordinal}-${suffix}`,
    retry_mapping_ref: "fixture-explicit-retry-mapping",
    environment: "test",
    billing_mode: "simulated",
    operation_kind: batch.adapter_snapshot.operation_kind,
    tenant_id: batch.tenant_id,
    project_id: batch.project_id,
    budget_scope_id: batch.policy_snapshot.budget_scope_id,
    budget: {
      scope_id: batch.policy_snapshot.budget_scope_id,
      policy_version: batch.policy_snapshot.policy_version,
    },
    provider: {
      name: batch.adapter_snapshot.provider_name,
      model: batch.adapter_snapshot.model,
      endpoint: batch.adapter_snapshot.endpoint,
      sdk: { name: batch.adapter_snapshot.sdk_name, version: batch.adapter_snapshot.sdk_version },
    },
  };
}

function event(batch, slot, eventType, fields = {}) {
  eventSequence += 1;
  return {
    tenant_id: batch.tenant_id,
    project_id: batch.project_id,
    action_id: batch.action_id,
    batch_id: batch.batch_id,
    concept_id: slot.concept_id,
    event_id: `fixture-event-${eventSequence}`,
    event_type: eventType,
    ...fields,
  };
}

function reserve(batch, slot, suffix) {
  const meteredAttempt = makeAttempt(batch, slot, suffix);
  const reservation = {
    status: "reserved",
    reservation_id: `reservation-${slot.ordinal}-${suffix}`,
    billable_attempt_id: meteredAttempt.billable_attempt_id,
    held_amount: { amount: "0.01", currency: "USD" },
    lease_id: `lease-${slot.ordinal}-${suffix}`,
  };
  const reserveEvent = event(batch, slot, "reserve_attempt", {
    billable_attempt_id: meteredAttempt.billable_attempt_id,
    transport_attempt_id: `transport-${slot.ordinal}-${suffix}`,
    metered_attempt: meteredAttempt,
    reservation,
  });
  return {
    reserveEvent,
    batch: applyCreativeConceptEvent(batch, reserveEvent).batch,
    billableAttemptId: meteredAttempt.billable_attempt_id,
    transportAttemptId: `transport-${slot.ordinal}-${suffix}`,
    reservationRef: reservation.reservation_id,
  };
}

function dispatch(batch, slot, identities) {
  const dispatchEvent = event(batch, slot, "dispatch_started", {
    billable_attempt_id: identities.billableAttemptId,
    transport_attempt_id: identities.transportAttemptId,
    dispatch_intent_ref: `dispatch-${identities.billableAttemptId}`,
    provider_target_binding_sha256: `sha256:${"d".repeat(64)}`,
    rendered_prompt_sha256: `sha256:${"e".repeat(64)}`,
  });
  return { event: dispatchEvent, batch: applyCreativeConceptEvent(batch, dispatchEvent).batch };
}

function providerOutcome(batch, slot, identities, outcome, artifactBytes, overrides = {}) {
  const fields = {
    billable_attempt_id: identities.billableAttemptId,
    transport_attempt_id: identities.transportAttemptId,
    outcome,
    outcome_evidence_ref: `provider-outcome-${identities.billableAttemptId}`,
    provider_request_id: `provider-request-${identities.billableAttemptId}`,
    ...(artifactBytes ? { artifact_sha256: hashArtifactBytes(artifactBytes) } : {}),
    usage_evidence_ref: `usage-observation-${identities.billableAttemptId}`,
    usage_completeness: "complete",
    ...overrides,
  };
  for (const [key, value] of Object.entries(fields)) if (value === undefined) delete fields[key];
  const outcomeEvent = event(batch, slot, "provider_outcome", fields);
  return { event: outcomeEvent, batch: applyCreativeConceptEvent(batch, outcomeEvent).batch };
}

function staged(batch, slot, identities, artifactBytes) {
  return inspectCreativeConceptImageBytes({
    bytes: artifactBytes,
    expected_media_type: "image/png",
    maximum_bytes: batch.policy_snapshot.maximum_single_reference_bytes,
  }).then((metadata) => {
    const stageEvent = event(batch, slot, "candidate_staged", {
      billable_attempt_id: identities.billableAttemptId,
      transport_attempt_id: identities.transportAttemptId,
      artifact_sha256: metadata.content_sha256,
      media_type: metadata.media_type,
      width: metadata.width,
      height: metadata.height,
      storage_stage_ref: `fixture-storage-stage-${identities.billableAttemptId}`,
      inspection_evidence_ref: `fixture-native-inspection-${identities.billableAttemptId}`,
    });
    return { event: stageEvent, batch: applyCreativeConceptEvent(batch, stageEvent).batch, metadata };
  });
}

function versionFor(batch, slot, metadata, suffix) {
  const version = {
    contract: "DesignVersion",
    schema_version: "1.0",
    event_id: `version-event-${suffix}`,
    tenant_id: batch.tenant_id,
    project_id: batch.project_id,
    correlation_id: `version-correlation-${suffix}`,
    producer: "synthetic-concept-fixture",
    occurred_at: FIXTURE_NOW,
    ingested_at: FIXTURE_NOW,
    environment: "test",
    billing_mode: "simulated",
    source_refs: [...new Set(batch.references.map((reference) => reference.source_ref))],
    design_version_id: `design-version-${suffix}`,
    parent_version_id: null,
    brief_hash: batch.brief_sha256,
    artifact: {
      artifact_id: `artifact-${suffix}`,
      content_hash: metadata.content_sha256,
      media_type: metadata.media_type,
    },
  };
  version.design_hash = computeDesignVersionHash(version);
  return version;
}

async function commitSyntheticCandidate(batch, slot, identities, bytes, suffix) {
  const output = providerOutcome(batch, slot, identities, "succeeded", bytes);
  const stagedResult = await staged(output.batch, slot, identities, bytes);
  const publishEvent = event(stagedResult.batch, slot, "candidate_published", {
    billable_attempt_id: identities.billableAttemptId,
    transport_attempt_id: identities.transportAttemptId,
    design_version: versionFor(stagedResult.batch, slot, stagedResult.metadata, suffix),
    storage_commit_ref: `fixture-storage-commit-${suffix}`,
    lineage_evidence_ref: `fixture-lineage-${suffix}`,
  });
  return {
    batch: applyCreativeConceptEvent(stagedResult.batch, publishEvent).batch,
    providerEvent: output.event,
    stageEvent: stagedResult.event,
    publishEvent,
  };
}

test("proposal creates ordered independent parentless slots from two scoped authorized assets", async () => {
  eventSequence = 0;
  const input = conceptProposalInput();
  const batch = createCreativeConceptBatchProposal(input);
  assert.equal(batch.acceptance_status, "unaccepted_local_proposal");
  assert.equal(batch.contract, CREATIVE_CONCEPT_PROPOSAL.contract);
  assert.equal(batch.requested_count, 2);
  assert.equal(batch.slots.length, 2);
  assert.equal(batch.references.length, 2);
  assert.deepEqual(batch.slots.map((slot) => slot.ordinal), [1, 2]);
  assert.notEqual(batch.slots[0].concept_id, batch.slots[1].concept_id);
  assert.notEqual(batch.slots[0].logical_operation_id, batch.slots[1].logical_operation_id);
  assert.equal(batch.slots.every((slot) => slot.parent_version_id === null && slot.status === "pending"), true);
  assert.equal(Object.isFrozen(batch.slots), true);
  assert.equal(batch.references[0].permission_evidence_ref, "fixture-permission-evidence-1");
  assert.equal(batch.adapter_snapshot.endpoint, "https://api.openai.com/v1/images/edits");
  assert.equal(batch.adapter_snapshot.prompt_template_ref, input.adapter_snapshot.prompt_template_ref);

  const bytes = conceptReferenceBytes();
  const resolved = await inspectCreativeConceptReferenceBytes(batch, batch.references.map((reference, index) => ({
    asset_id: reference.asset_id,
    bytes: bytes[index],
  })));
  assert.equal(resolved.references.length, 2);
  assert.equal(resolved.aggregate_byte_length, bytes[0].byteLength + bytes[1].byteLength);
  assert.deepEqual(resolved.references.map((reference) => reference.content_sha256), batch.references.map((reference) => reference.content_hash));
  assert.equal("bytes" in resolved.references[0], false);

  let current = batch;
  const identities = [];
  for (const [index, originalSlot] of batch.slots.entries()) {
    const slot = current.slots[index];
    const reserved = reserve(current, slot, `first-${index}`);
    identities.push(reserved);
    current = reserved.batch;
    current = dispatch(current, current.slots[index], reserved).batch;
    const outcome = providerOutcome(current, current.slots[index], reserved, "succeeded", bytes[index]);
    current = outcome.batch;
    const stageResult = await staged(current, current.slots[index], reserved, bytes[index]);
    current = stageResult.batch;
    assert.equal(current.slots[index].status, "staged");
    assert.equal(current.slots[index].output_lineage, null, "staged bytes are still invisible before the commit event");
    const publishEvent = event(current, current.slots[index], "candidate_published", {
      billable_attempt_id: reserved.billableAttemptId,
      transport_attempt_id: reserved.transportAttemptId,
      design_version: versionFor(current, current.slots[index], stageResult.metadata, `case1-${index}`),
      storage_commit_ref: `fixture-storage-commit-case1-${index}`,
      lineage_evidence_ref: `fixture-lineage-case1-${index}`,
    });
    current = applyCreativeConceptEvent(current, publishEvent).batch;
  }
  assert.equal(current.slots.every((slot) => slot.status === "succeeded"), true);
  assert.equal(current.slots.every((slot) => slot.output_lineage.parent_version_id === null), true);
  assert.equal(current.slots.every((slot) => slot.output_lineage.configuration_sha256 === input.adapter_snapshot.configuration_sha256), true);
  assert.equal(current.slots.every((slot) => slot.output_lineage.prompt_template_sha256 === input.adapter_snapshot.prompt_template_sha256), true);
  assert.equal(current.slots.every((slot) => slot.output_lineage.usage_evidence_refs.length === 1), true);
  assert.equal(current.slots.every((slot) => slot.attempts.length === 1), true);
  assert.deepEqual(identities.map((identity) => identity.billableAttemptId), ["billable-1-first-0", "billable-2-first-1"]);
});

test("invalid count, stale scope, revoked rights, and expired policy reject before a C03 attempt exists", () => {
  expectCode("invalid_integer", () => createCreativeConceptBatchProposal(conceptProposalInput({
    request: { ...conceptProposalInput().request, requested_count: 0 },
  })));
  const excess = conceptProposalInput();
  excess.policy_snapshot.maximum_concept_count = 1;
  expectCode("policy_limit_exceeded", () => createCreativeConceptBatchProposal(excess));

  const staleBrief = conceptProposalInput();
  staleBrief.brief_sha256 = `sha256:${"0".repeat(64)}`;
  expectCode("brief_hash_mismatch", () => createCreativeConceptBatchProposal(staleBrief));

  const revoked = conceptProposalInput();
  revoked.permission_evidence[0].status = "denied";
  expectCode("reference_permission_denied", () => createCreativeConceptBatchProposal(revoked));

  const crossScope = conceptProposalInput();
  crossScope.permission_evidence[1].project_id = "another-project";
  expectCode("reference_permission_scope_mismatch", () => createCreativeConceptBatchProposal(crossScope));

  const noRights = conceptProposalInput();
  noRights.permission_evidence = [];
  expectCode("reference_permission_missing", () => createCreativeConceptBatchProposal(noRights));

  const stalePermission = conceptProposalInput();
  stalePermission.permission_evidence[0].expires_at = FIXTURE_NOW;
  expectCode("reference_permission_expired", () => createCreativeConceptBatchProposal(stalePermission));

  const expiredBudget = conceptProposalInput();
  expiredBudget.policy_snapshot.budget_expires_at = FIXTURE_NOW;
  expectCode("policy_snapshot_expired", () => createCreativeConceptBatchProposal(expiredBudget));

  const expiredCountPolicy = conceptProposalInput();
  expiredCountPolicy.policy_snapshot.expires_at = FIXTURE_NOW;
  expectCode("policy_snapshot_expired", () => createCreativeConceptBatchProposal(expiredCountPolicy));
});

test("native codec and content hash reject invalid outputs and retain exact read-only byte snapshots", async () => {
  const [valid, second] = conceptReferenceBytes();
  const snapshot = Buffer.from(valid);
  const pending = inspectCreativeConceptImageBytes({ bytes: valid, expected_media_type: "image/png", maximum_bytes: 1_000_000 });
  valid.fill(0);
  const inspected = await pending;
  assert.equal(inspected.content_sha256, hashArtifactBytes(snapshot));
  assert.deepEqual([inspected.width, inspected.height], [16, 16]);

  await assert.rejects(inspectCreativeConceptImageBytes({ bytes: new Uint8Array(), expected_media_type: "image/png", maximum_bytes: 100 }),
    (error) => error?.code === "image_bytes_out_of_bounds");
  await assert.rejects(inspectCreativeConceptImageBytes({ bytes: corruptPngCrc(second), expected_media_type: "image/png", maximum_bytes: 1_000_000 }),
    (error) => error?.code === "image_inspection_failed");
  await assert.rejects(inspectCreativeConceptImageBytes({ bytes: second, expected_media_type: "image/jpeg", maximum_bytes: 1_000_000 }),
    (error) => error?.code === "image_media_type_mismatch");
  await assert.rejects(inspectCreativeConceptImageBytes({
    bytes: second,
    expected_media_type: "image/png",
    maximum_bytes: 1_000_000,
    expected_dimensions: { width: 16, height: 16 },
  }), (error) => error?.code === "image_dimensions_mismatch");

  const batch = createCreativeConceptBatchProposal(conceptProposalInput({
    policy_snapshot: { ...conceptProposalInput().policy_snapshot, maximum_aggregate_reference_bytes: 1 },
  }));
  const [ref1, ref2] = conceptReferenceBytes();
  await assert.rejects(inspectCreativeConceptReferenceBytes(batch, batch.references.map((reference, index) => ({
    asset_id: reference.asset_id,
    bytes: [ref1, ref2][index],
  }))), (error) => error?.code === "reference_bytes_out_of_bounds");
});

test("rejected provider bytes retain attempt and usage evidence without staging or publication", async () => {
  eventSequence = 0;
  const batch = createCreativeConceptBatchProposal(conceptProposalInput());
  const slot = batch.slots[0];
  const invalidBytes = corruptPngCrc(conceptReferenceBytes()[0]);
  const identities = reserve(batch, slot, "invalid-artifact");
  let current = dispatch(identities.batch, identities.batch.slots[0], identities).batch;
  current = providerOutcome(current, current.slots[0], identities, "succeeded", invalidBytes).batch;

  let inspectionFailure;
  try {
    await inspectCreativeConceptImageBytes({
      bytes: invalidBytes,
      expected_media_type: "image/png",
      maximum_bytes: current.policy_snapshot.maximum_single_reference_bytes,
    });
  } catch (error) {
    inspectionFailure = error;
  }
  assert.equal(inspectionFailure?.code, "image_inspection_failed");

  const rejected = event(current, current.slots[0], "artifact_rejected", {
    billable_attempt_id: identities.billableAttemptId,
    transport_attempt_id: identities.transportAttemptId,
    artifact_sha256: hashArtifactBytes(invalidBytes),
    failure_code: inspectionFailure.code,
    inspection_evidence_ref: "native-codec-rejected-provider-bytes",
  });
  current = applyCreativeConceptEvent(current, rejected).batch;
  const failedSlot = current.slots[0];
  const failedAttempt = failedSlot.attempts[0];
  assert.equal(failedSlot.status, "failed");
  assert.equal(failedSlot.output_lineage, null);
  assert.equal(failedAttempt.status, "failed_artifact");
  assert.equal(failedAttempt.staged_artifact, undefined);
  assert.deepEqual(failedAttempt.artifact_validation_failure, {
    artifact_sha256: hashArtifactBytes(invalidBytes),
    failure_code: "image_inspection_failed",
    inspection_evidence_ref: "native-codec-rejected-provider-bytes",
  });
  assert.equal(failedAttempt.provider_observations[0].outcome, "succeeded");
  assert.equal(failedAttempt.provider_observations[0].artifact_sha256, hashArtifactBytes(invalidBytes));
  assert.deepEqual(failedAttempt.usage_evidence_refs, [`usage-observation-${identities.billableAttemptId}`]);
  assert.equal(failedAttempt.unknown_financial_exposure, false);

  const retry = reserve(current, failedSlot, "invalid-artifact-retry");
  assert.notEqual(retry.billableAttemptId, identities.billableAttemptId);
  assert.equal(retry.batch.slots[0].attempts.length, 2);
  assert.equal(retry.batch.slots[0].attempts[0].artifact_validation_failure.failure_code, "image_inspection_failed");
});

test("staged media must match the explicit adapter output format", () => {
  eventSequence = 0;
  const batch = createCreativeConceptBatchProposal(conceptProposalInput());
  const slot = batch.slots[0];
  const bytes = conceptReferenceBytes()[0];
  const identities = reserve(batch, slot, "output-format");
  let current = dispatch(identities.batch, identities.batch.slots[0], identities).batch;
  current = providerOutcome(current, current.slots[0], identities, "succeeded", bytes).batch;
  expectCode("adapter_output_format_mismatch", () => applyCreativeConceptEvent(current, event(current, current.slots[0], "candidate_staged", {
    billable_attempt_id: identities.billableAttemptId,
    transport_attempt_id: identities.transportAttemptId,
    artifact_sha256: hashArtifactBytes(bytes),
    media_type: "image/jpeg",
    width: 16,
    height: 16,
    storage_stage_ref: "must-not-stage-wrong-format",
    inspection_evidence_ref: "wrong-format-inspection",
  })));
});

test("same action replay compares canonical request and returns the exact stored partial state", async () => {
  eventSequence = 0;
  const input = conceptProposalInput();
  const original = createCreativeConceptBatchProposal(input);
  const first = reserve(original, original.slots[0], "replay");
  const second = dispatch(first.batch, first.batch.slots[0], first);
  const partial = providerOutcome(second.batch, second.batch.slots[0], first, "failed", null, {
    usage_completeness: "complete",
    artifact_sha256: undefined,
  }).batch;
  const replay = replayCreativeConceptBatch(partial, {
    trusted_scope: input.trusted_scope,
    request: input.request,
  });
  assert.equal(replay.status, "replayed");
  assert.equal(replay.batch, partial);
  assert.equal(replay.batch.slots[0].attempts.length, 1);
  expectCode("action_replay_conflict", () => replayCreativeConceptBatch(partial, {
    trusted_scope: input.trusted_scope,
    request: { ...input.request, requested_count: 1 },
  }));
  expectCode("replay_scope_mismatch", () => replayCreativeConceptBatch(partial, {
    trusted_scope: { ...input.trusted_scope, project_id: "different-project" },
    request: input.request,
  }));
});

test("known failure retries only through a distinct C03 reservation and completed slots never regenerate", async () => {
  eventSequence = 0;
  const batch = createCreativeConceptBatchProposal(conceptProposalInput());
  const [outputOne, outputTwo] = conceptReferenceBytes();
  const firstReserved = reserve(batch, batch.slots[0], "original");
  const duplicate = applyCreativeConceptEvent(firstReserved.batch, firstReserved.reserveEvent);
  assert.equal(duplicate.status, "duplicate");
  assert.equal(duplicate.batch, firstReserved.batch);
  const collision = { ...firstReserved.reserveEvent, reservation: { ...firstReserved.reserveEvent.reservation, lease_id: "changed-lease" } };
  expectCode("event_identity_conflict", () => applyCreativeConceptEvent(firstReserved.batch, collision));

  let current = firstReserved.batch;
  current = dispatch(current, current.slots[0], firstReserved).batch;
  current = providerOutcome(current, current.slots[0], firstReserved, "failed", null, { usage_completeness: "complete" }).batch;
  const repeatedIdentity = {
    ...event(current, current.slots[0], "reserve_attempt", {}),
    billable_attempt_id: firstReserved.billableAttemptId,
    transport_attempt_id: "different-transport-for-old-billable",
    metered_attempt: makeAttempt(current, current.slots[0], "original"),
    reservation: {
      status: "reserved",
      reservation_id: "different-reservation-for-old-billable",
      billable_attempt_id: firstReserved.billableAttemptId,
      held_amount: { amount: "0.01", currency: "USD" },
      lease_id: "different-lease-for-old-billable",
    },
  };
  expectCode("attempt_identity_reused", () => applyCreativeConceptEvent(current, repeatedIdentity));
  const retry = reserve(current, current.slots[0], "retry-1");
  assert.notEqual(retry.billableAttemptId, firstReserved.billableAttemptId);
  assert.notEqual(retry.transportAttemptId, firstReserved.transportAttemptId);
  assert.notEqual(retry.reservationRef, firstReserved.reservationRef);

  current = dispatch(retry.batch, retry.batch.slots[0], retry).batch;
  const completed = await commitSyntheticCandidate(current, current.slots[0], retry, outputOne, "retry-completed");
  expectCode("terminal_state_immutable", () => applyCreativeConceptEvent(completed.batch, event(completed.batch, completed.batch.slots[0], "reserve_attempt", {
    billable_attempt_id: "billable-new-after-success",
    transport_attempt_id: "transport-new-after-success",
    metered_attempt: makeAttempt(completed.batch, completed.batch.slots[0], "new-after-success"),
    reservation: {
      status: "reserved", reservation_id: "reservation-new-after-success", billable_attempt_id: "billable-new-after-success",
      held_amount: { amount: "0.01", currency: "USD" }, lease_id: "lease-new-after-success",
    },
  })));

  let unaffected = completed.batch;
  const secondSlot = unaffected.slots[1];
  const independent = reserve(unaffected, secondSlot, "independent");
  unaffected = independent.batch;
  unaffected = dispatch(unaffected, unaffected.slots[1], independent).batch;
  unaffected = providerOutcome(unaffected, unaffected.slots[1], independent, "succeeded", outputTwo).batch;
  assert.equal(unaffected.slots[0].status, "succeeded");
  assert.equal(unaffected.slots[1].status, "response_received");
});

test("unknown attempt reconciles only on the same identity and keeps its unknown financial exposure", async () => {
  eventSequence = 0;
  const batch = createCreativeConceptBatchProposal(conceptProposalInput());
  const bytes = conceptReferenceBytes()[0];
  const reserved = reserve(batch, batch.slots[0], "unknown");
  let current = dispatch(reserved.batch, reserved.batch.slots[0], reserved).batch;
  const unknown = providerOutcome(current, current.slots[0], reserved, "unknown", null, {
    usage_completeness: "unknown",
    usage_evidence_ref: "unknown-exposure-evidence",
  });
  current = unknown.batch;
  assert.equal(current.slots[0].status, "unknown");
  expectCode("dispatch_not_allowed", () => applyCreativeConceptEvent(current, event(current, current.slots[0], "reserve_attempt", {
    billable_attempt_id: "billable-regenerated-after-unknown",
    transport_attempt_id: "transport-regenerated-after-unknown",
    metered_attempt: makeAttempt(current, current.slots[0], "regenerated-after-unknown"),
    reservation: {
      status: "reserved", reservation_id: "reservation-regenerated-after-unknown", billable_attempt_id: "billable-regenerated-after-unknown",
      held_amount: { amount: "0.01", currency: "USD" }, lease_id: "lease-regenerated-after-unknown",
    },
  })));

  const known = event(current, current.slots[0], "reconcile_unknown_attempt", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    outcome: "succeeded",
    outcome_evidence_ref: "same-attempt-late-provider-result",
    provider_request_id: "provider-request-late-known",
    artifact_sha256: hashArtifactBytes(bytes),
    usage_evidence_ref: "same-attempt-late-usage-observation",
    usage_completeness: "complete",
  });
  current = applyCreativeConceptEvent(current, known).batch;
  const attempt = current.slots[0].attempts[0];
  assert.equal(current.slots[0].status, "response_received");
  assert.deepEqual(attempt.provider_observations.map((item) => item.outcome), ["unknown", "succeeded"]);
  assert.deepEqual(attempt.usage_evidence_refs, ["unknown-exposure-evidence", "same-attempt-late-usage-observation"]);
  assert.equal(attempt.unknown_financial_exposure, true);
  assert.equal(attempt.financial_exposure_status, "unknown_hold");
  const stagedResult = await staged(current, current.slots[0], reserved, bytes);
  current = stagedResult.batch;
  const metadataEvent = event(current, current.slots[0], "reconcile_staged_metadata", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    artifact_sha256: hashArtifactBytes(bytes),
    metadata_evidence_ref: "same-bytes-metadata-reconciled",
  });
  current = applyCreativeConceptEvent(current, metadataEvent).batch;
  assert.equal(current.slots[0].attempts[0].storage_metadata_evidence_refs[0], "same-bytes-metadata-reconciled");
  const publishEvent = event(current, current.slots[0], "candidate_published", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    design_version: versionFor(current, current.slots[0], stagedResult.metadata, "unknown-reconciled"),
    storage_commit_ref: "same-attempt-reconciled-commit",
    lineage_evidence_ref: "same-attempt-reconciled-lineage",
  });
  current = applyCreativeConceptEvent(current, publishEvent).batch;
  assert.equal(current.slots[0].status, "succeeded");
  assert.equal(current.slots[0].output_lineage.unknown_financial_exposure, true);
  assert.equal(current.slots[0].output_lineage.usage_evidence_refs.includes("unknown-exposure-evidence"), true);
});

test("cancellation suppresses same-attempt late success while retaining evidence and the unknown hold", () => {
  eventSequence = 0;
  const batch = createCreativeConceptBatchProposal(conceptProposalInput());
  const bytes = conceptReferenceBytes()[0];
  const reserved = reserve(batch, batch.slots[0], "cancelled");
  let current = dispatch(reserved.batch, reserved.batch.slots[0], reserved).batch;
  const cancel = event(current, current.slots[0], "cancel_concept", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    cancellation_evidence_ref: "owner-cancellation-event-ref",
  });
  current = applyCreativeConceptEvent(current, cancel).batch;
  assert.equal(current.slots[0].status, "cancelled");
  assert.equal(current.slots[0].attempts[0].financial_exposure_status, "unknown_hold");

  const late = event(current, current.slots[0], "late_provider_evidence", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    outcome: "succeeded",
    outcome_evidence_ref: "late-success-after-cancel",
    provider_request_id: "late-provider-request",
    artifact_sha256: hashArtifactBytes(bytes),
    usage_evidence_ref: "late-usage-observation",
    usage_completeness: "unknown",
  });
  current = applyCreativeConceptEvent(current, late).batch;
  assert.equal(current.slots[0].status, "cancelled");
  assert.equal(current.slots[0].output_lineage, null);
  assert.equal(current.slots[0].late_evidence.length, 1);
  assert.equal(current.slots[0].attempts[0].provider_observations[0].publication_suppressed, true);
  assert.equal(current.slots[0].attempts[0].unknown_financial_exposure, true);
  const publishEvent = event(current, current.slots[0], "candidate_published", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    design_version: {},
    storage_commit_ref: "must-not-publish",
    lineage_evidence_ref: "must-not-publish",
  });
  expectCode("event_identity_conflict", () => applyCreativeConceptEvent(current, { ...publishEvent, event_id: cancel.event_id }));
  expectCode("terminal_state_immutable", () => applyCreativeConceptEvent(current, publishEvent));
  expectCode("terminal_state_immutable", () => applyCreativeConceptEvent(current, event(current, current.slots[0], "cancel_concept", {
    billable_attempt_id: reserved.billableAttemptId,
    transport_attempt_id: reserved.transportAttemptId,
    cancellation_evidence_ref: "second-cancel",
  })));
});
