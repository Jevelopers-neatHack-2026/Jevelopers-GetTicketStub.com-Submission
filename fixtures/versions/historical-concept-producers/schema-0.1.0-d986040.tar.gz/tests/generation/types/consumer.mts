import {
  applyCreativeConceptEvent,
  createCreativeConceptBatchProposal,
  inspectCreativeConceptImageBytes,
  replayCreativeConceptBatch,
} from "../../../src/generation/concepts.mjs";
import type {
  CreativeConceptBatchEvent,
  CreativeConceptBatchProposal,
  CreativeConceptBatchProposalInput,
} from "../../../src/generation/concepts.mjs";

declare const input: CreativeConceptBatchProposalInput;
declare const batch: CreativeConceptBatchProposal;
declare const event: CreativeConceptBatchEvent;

const created = createCreativeConceptBatchProposal(input);
const updated = applyCreativeConceptEvent(created, event);
const replayed = replayCreativeConceptBatch(updated.batch, { trusted_scope: input.trusted_scope, request: input.request });
const rejectedArtifact = applyCreativeConceptEvent(created, {
  tenant_id: created.tenant_id,
  project_id: created.project_id,
  action_id: created.action_id,
  batch_id: created.batch_id,
  concept_id: created.slots[0].concept_id,
  event_id: "artifact-rejection-event",
  event_type: "artifact_rejected",
  billable_attempt_id: "billable-attempt",
  transport_attempt_id: "transport-attempt",
  artifact_sha256: `sha256:${"a".repeat(64)}`,
  failure_code: "image_inspection_failed",
  inspection_evidence_ref: "native-inspection-evidence",
});
const imageCheck = inspectCreativeConceptImageBytes({
  bytes: new Uint8Array([1]),
  expected_media_type: "image/png",
  maximum_bytes: 100,
  expected_dimensions: { width: 1, height: 1 },
});

void batch;
void rejectedArtifact;
void replayed;
void imageCheck;
