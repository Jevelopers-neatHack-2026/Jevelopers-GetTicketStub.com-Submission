# TicketStub — 2:50 draft narration

**This is a recording script, not a claim that the required live footage has already been captured.**

**00:00–00:12 · THE MEMORY PROBLEM**

A great night ends. The ticket gets lost. TicketStub turns a link to that event into a keepsake you actually want to keep.

**00:12–00:30 · ONE LINK. ONE GOAL.**

Start with an event link. The goal is to understand the event and create a personal, accurate ticket, without making someone fill out a long form.

**00:30–00:54 · THE AGENT AT WORK**

The studio gathers event facts and sources, chooses the next action, and brings the design together. We can review the result, keep versions, and download the exact ticket.

**00:54–01:09 · DECISIONS + STATE**

Underneath, research, an agent harness, and a creative engine handle evidence, decisions, and persistence. The individual components are tested, but complete cross-repository acceptance remains open.

**01:09–01:31 · NEATLOGS: SEE THE RUN**

Neatlogs exposes the real agent trace. We recorded a successful research run and a separate request that timed out before an LLM call. The spans show exactly where the work stopped.

**01:31–01:51 · ENTIRE: CHANGE CONTEXT**

Entire gives the coding process durable context. We used GitHub Actions to capture codebase graphs across ten repositories, and preserved one historical coding checkpoint. Those artifacts make changes inspectable.

**01:51–02:10 · CFO.AI: PLAN THE BUSINESS**

In cfo.ai, we built a business model covering pricing, costs, revenue scenarios, and cash runway. We corrected edge cases and checked the exported workbook. These figures are forecasts, not earnings.

**02:10–02:31 · FAILURE / NEXT ACTION**

Reliability matters when tools fail. One recorded event lookup timed out before spending on an LLM. We added bounded fetch handling, and our next proof target is a single, fully observed recovery run.

**02:31–02:43 · BUILT IN PUBLIC**

Everything is inspectable: the public repositories, dated commits, pull requests and unresolved issues. We are showing our work, including what is not yet finished.

**02:43–02:50 · KEEP THE NIGHT.**

TicketStub: from event link to keepsake. Watch the demo. Check the GitHub evidence.

## Narration constraints

- Do not read source URLs aloud. Show a readable lower-third and supply repo links in the X post or GitHub README.
- Match actual recording modes: switch "the studio gathers" to "in demo mode, the fixture supplies" when using fixtures.
- Any recovery or improvement sentence requires a real new capture; the script currently states the evidence gap.
- Maintain 2:50 total. Allow natural pauses within the longer product and sponsor scenes, not by lengthening the export past 3:00.
