# TicketStub · neatHack 2026 judge-aligned video storyboard

**Target runtime:** 02:50 (170 seconds). **Hard maximum:** 03:00. **Picture:** 1920×1080, 16:9. **Style:** original TicketStub brand palette (Night Ink, Stub Cream, Copper, Ticket Orange, Stage Moss, Holo Cyan).

**Submission target:** A real product demonstration, not a historical progress montage. The illustrations are planning placeholders. The final video must show authentic product and partner-tool captures and evidence.

**Hackathon rules:** [official judging, required partners and video instructions](https://neatlogs.com/hackathon). The video must explicitly cover **architecture, implementation, runtime, reasoning and result for EACH of neatlogs, Entire and cfo.ai**, stay at or under 3 minutes, and accompany a public repository and official X quote-post.

## Judge-weight alignment

| Category | Weight | How this edit earns attention |
|---|---:|---|
| The agent | 30% | Product run, tool choice, state, failure handling, checked result (scenes 2–4, 8, 10). |
| neatlogs + Entire + cfo.ai | 25% | Distinct authentic demonstrations of each required partner (scenes 5–7). |
| Demo video | 20% | Clear hook, one chronological live product session, captioned proof, restrained edit, honest limitations. |
| Building in public | 15% | Public GitHub history plus real #neatHack sharing links (scene 9). |
| Usefulness and originality | 10% | Emotional need and distinctive sourced, designable keepsake (scenes 1 and 10). |

## 2:50 edit decision list

| # | In–out | Seconds | Scene | What MUST appear |
|---:|---|---:|---|---|
| 1 | 00:00–00:12 | 12 | THE MEMORY PROBLEM | OPENING / EXPLAIN THE PROBLEM |
| 2 | 00:12–00:30 | 18 | ONE LINK. ONE GOAL. | LIVE PRODUCT CAPTURE REQUIRED |
| 3 | 00:30–00:54 | 24 | THE AGENT AT WORK | LIVE PRODUCT + RESULT REQUIRED |
| 4 | 00:54–01:09 | 15 | DECISIONS + STATE | ARCHITECTURE / IMPLEMENTATION |
| 5 | 01:09–01:31 | 22 | NEATLOGS: SEE THE RUN | ACTUAL TRACE SCREEN RECORDING |
| 6 | 01:31–01:51 | 20 | ENTIRE: CHANGE CONTEXT | REAL ENTIRE ARTIFACT CAPTURE |
| 7 | 01:51–02:10 | 19 | CFO.AI: PLAN THE BUSINESS | REAL CFO.AI CANVAS CAPTURE |
| 8 | 02:10–02:31 | 21 | FAILURE / NEXT ACTION | FAILURE / RECOVERY EVIDENCE GAP |
| 9 | 02:31–02:43 | 12 | BUILT IN PUBLIC | PUBLIC REPOS + ACTUAL POST EVIDENCE |
| 10 | 02:43–02:50 | 7 | KEEP THE NIGHT. | SHOW AUTHENTIC PRODUCT RESULT |

## Individual shot cards

### 01. THE MEMORY PROBLEM · 00:00–00:12

**Judging:** USEFULNESS · 10%. **On-screen:** A concert ends. The original ticket disappears. TicketStub makes the moment collectible.

**Capture/edit:** Show real phone-gallery clutter or one generic event URL, then reveal a stylized printed TicketStub artifact. Concept art may be used here, but not mislabeled as the product.

**Voice-over:** A great night ends. The ticket gets lost. TicketStub turns a link to that event into a keepsake you actually want to keep.

**Current evidence:** Product concept described in the organization profile and brand specification.

**Required footage:** Product beauty shot or recorded existing studio output; no unsupported print-production claim.

**Do not overclaim:** Conceptual visuals are fine for the opening, but the final result later must be authentic.

**Links:**
- [org](https://github.com/Jevelopers-neatHack-2026)
- [product readme](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/blob/main/README.md)

### 02. ONE LINK. ONE GOAL. · 00:12–00:30

**Judging:** THE AGENT · 30%. **On-screen:** Open the actual studio. Paste an event URL. Show the mode (LIVE or DEMO) honestly.

**Capture/edit:** Replace illustration with uninterrupted capture of getticketstub.com: paste a safe public event URL or use an explicitly labeled fixture; show intake and resulting state. Avoid montage that hides errors.

**Voice-over:** Start with an event link. The goal is to understand the event and create a personal, accurate ticket, without making someone fill out a long form.

**Current evidence:** Next.js studio is merged; URL-first guarded intake was also merged.

**Required footage:** Actual browser recording; show cursor, URL intake, on-screen runtime mode and any consent/status.

**Do not overclaim:** Default demo uses fixture research and simulated art; label it. Only say live retrieval if filmed live.

**Links:**
- [studio](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/5)
- [url](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/79)
- [product readme](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/blob/main/README.md)

### 03. THE AGENT AT WORK · 00:30–00:54

**Judging:** THE AGENT · 30%. **On-screen:** Gather event facts → choose actions → make art. Review, save and export the exact stub.

**Capture/edit:** Screen-record a single contiguous demo from research/status to the event facts, generated or demo-labeled artwork, applied design, wall and the exact PNG download. Do not splice separate fake runs into one.

**Voice-over:** The studio gathers event facts and sources, chooses the next action, and brings the design together. We can review the result, keep versions, and download the exact ticket.

**Current evidence:** The customer studio, typed agent actions, artwork approval and exact PNG download are merged.

**Required footage:** Capture one real end-to-end app session, plus a brief exported file view and actual mode badge.

**Do not overclaim:** Never imply all specialist repos run end-to-end in production merely because individual foundations merged.

**Links:**
- [studio](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/5)
- [download](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/61)
- [product readme](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/blob/main/README.md)

### 04. DECISIONS + STATE · 00:54–01:09

**Judging:** THE AGENT · 30%. **On-screen:** Research · decisions · creative · persistence. Bounded work, explicit failures, checked results.

**Capture/edit:** Use this diagram for a 5-second overlay, then insert a real screen/codelens of an agent transition, bounded attempt, checkpoint or tested restart. Distinguish foundations from an integrated release.

**Voice-over:** Underneath, research, an agent harness, and a creative engine handle evidence, decisions, and persistence. The individual components are tested, but complete cross-repository acceptance remains open.

**Current evidence:** Agent workflow recovery, sourced research storage and immutable artwork persistence merged in specialist repos.

**Required footage:** Optional code/CI capture for exact PR; do not claim deployed integrated harness unless demonstrated.

**Do not overclaim:** Architecture diagram shows intended boundaries. Unproven cross-repository connections are not asserted.

**Links:**
- [agent](https://github.com/Jevelopers-neatHack-2026/agent-harness/pull/30)
- [research](https://github.com/Jevelopers-neatHack-2026/event-intelligence/pull/28)
- [creative](https://github.com/Jevelopers-neatHack-2026/creative-engine/pull/27)
- [checklist](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/planning/acceptance-checklist.json)

### 05. NEATLOGS: SEE THE RUN · 01:09–01:31

**Judging:** REQUIRED TOOLS · 25% TOTAL. **On-screen:** Real trace: research OK in 6.9 s. Separate trace: fetch timeout in 8.0 s.

**Capture/edit:** Open authentic neatlogs trace dashboard if credentials permit; otherwise zoom the repo-retained success and failure screenshots. Show exporter code (architecture + implementation), span tree/cost/timing (runtime), observed diagnosis (reasoning), and qualified result. Show no invented before/after.

**Voice-over:** Neatlogs exposes the real agent trace. We recorded a successful research run and a separate request that timed out before an LLM call. The spans show exactly where the work stopped.

**Current evidence:** Curated owner/agent evidence includes screenshots of a 6.9-second successful research run and an 8.0-second timed-out fetch; trace-to-deployment linkage and costs have qualifications.

**Required footage:** Dashboard screen recording or actual screenshot with trace ID, spans and timings; zoom for readability.

**Do not overclaim:** Different runs are not a measured before/after improvement. Do not claim precise billing or 100% trace capture.

**Links:**
- [neatlogs](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/neatlogs/2026-10-11/README.md)
- [neatlogs img](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/neatlogs/2026-10-11/trace-research-success.jpg)
- [neatlogs fail](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/neatlogs/2026-10-11/trace-research-failure.jpg)
- [neatlogs pr](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/46)

### 06. ENTIRE: CHANGE CONTEXT · 01:31–01:51

**Judging:** REQUIRED TOOLS · 25% TOTAL. **On-screen:** One recorded historical coding checkpoint. Ten entire-graph workflow snapshots.

**Capture/edit:** Screen-record the public Entire graph GitHub Actions run, open its snapshot/lineage, then show the historical checkpoint evidence. Explain git-refs/private checkpoint architecture, GitHub Actions implementation, actual graph output, how it informed code comprehension, and the saved result.

**Voice-over:** Entire gives the coding process durable context. We used GitHub Actions to capture codebase graphs across ten repositories, and preserved one historical coding checkpoint. Those artifacts make changes inspectable.

**Current evidence:** Public exact-main graph snapshots from ten repositories plus documented historical Claude checkpoint; current continuous agent checkpoint capture is not established.

**Required footage:** Genuine GitHub Actions Entire graph snapshot view plus historical checkpoint evidence, not a fabricated graph UI.

**Do not overclaim:** Do not claim the graph itself is an autonomous agent or that all agents had active Entire hooks.

**Links:**
- [entire](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/entire/2026-10-11/README.md)
- [entire graph](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/actions/runs/38166575087)

### 07. CFO.AI: PLAN THE BUSINESS · 01:51–02:10

**Judging:** REQUIRED TOOLS · 25% TOTAL. **On-screen:** Pricing, costs, scenarios and runway. Forecasts are hypothetical—not revenue.

**Capture/edit:** Capture the actual CFO.ai canvas with an assumption being changed and show the scenario result. Briefly overlay architecture (business planning), input implementation, runtime canvas, reasoning about economics, and export/Excel verified result.

**Voice-over:** In cfo.ai, we built a business model covering pricing, costs, revenue scenarios, and cash runway. We corrected edge cases and checked the exported workbook. These figures are forecasts, not earnings.

**Current evidence:** CFO.ai revision 2 canvas/export exists with Excel recalculation evidence; generic export has unresolved Finance reviewer finding.

**Required footage:** Actual CFO.ai canvas screen recording; avoid exposing account details; show one input/scenario and its output.

**Do not overclaim:** No actual sales, verified runway achievement or final Finance approval is implied.

**Links:**
- [cfo](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/cfo-ai/2026-10-11-r2/README.md)
- [cfo screenshot](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/cfo-ai/2026-10-11-r2/cfo-canvas-overview.jpg)
- [cfo verify](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/cfo-ai/2026-10-11-r2/VERIFICATION.md)

### 08. FAILURE / NEXT ACTION · 02:10–02:31

**Judging:** THE AGENT · 30%. **On-screen:** A real event lookup timed out. Record the next bounded action or fallback.

**Capture/edit:** Best: record one new controlled run showing failure → agent choice → retry or fallback → checked outcome, plus trace IDs. Existing archive proves a timeout and owner-reported malformed-art fallback separately, not a causal before/after or same-run autonomous recovery.

**Voice-over:** Reliability matters when tools fail. One recorded event lookup timed out before spending on an LLM. We added bounded fetch handling, and our next proof target is a single, fully observed recovery run.

**Current evidence:** Neatlogs timeout screenshot and merged retry/partial-art-input handling PR; held-out before/after improvement not demonstrated.

**Required footage:** Capture actual reproducible failure and following agent action, preferably in one trace; otherwise show the exact existing trace and qualify next steps.

**Do not overclaim:** Do not animate a fake successful retry as a real agent recovery. If the clip is unavailable, say recovery is not yet verified.

**Links:**
- [neatlogs fail](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/evidence/neatlogs/2026-10-11/trace-research-failure.jpg)
- [error](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/78)
- [checklist](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/planning/acceptance-checklist.json)

### 09. BUILT IN PUBLIC · 02:31–02:43

**Judging:** PUBLIC BUILD · 15%. **On-screen:** 14 public repositories and dated commits. Add genuine #neatHack posts if published.

**Capture/edit:** Record public GitHub PR timeline, at least one implementation commit dated inside event code window, and actual #neatHack X posts if they exist. Do not imply pre-event documentation was event-authored code.

**Voice-over:** Everything is inspectable: the public repositories, dated commits, pull requests and unresolved issues. We are showing our work, including what is not yet finished.

**Current evidence:** Fourteen public repos and PR history visible; #neatHack X posts must be verified independently before claiming them.

**Required footage:** Show actual GitHub dates, an implementation commit at or after Oct 10, 12:30 PM IST, and the genuine #neatHack post, if available.

**Do not overclaim:** The repos existed before the coding window; distinguish permitted planning/setup from code written during the event.

**Links:**
- [org](https://github.com/Jevelopers-neatHack-2026)
- [public pr](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pulls?q=is%3Apr+is%3Amerged)
- [public issues](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/issues)
- [rules](https://neatlogs.com/hackathon)

### 10. KEEP THE NIGHT. · 02:43–02:50

**Judging:** RESULT / CALL TO ACTION. **On-screen:** A downloadable commemorative stub. Test-mode checkout; release gates remain.

**Capture/edit:** Return to the genuine exported PNG / saved wall. Overlay repo URL and team/project name. Do not imply a paid order or printed shipment occurred. Keep title/end card under 7 seconds.

**Voice-over:** TicketStub: from event link to keepsake. Watch the demo. Check the GitHub evidence.

**Current evidence:** Exact PNG export and sandbox checkout changes merged; full v1 and production payment/fulfillment acceptance not established.

**Required footage:** Use the exact real saved/downloaded ticket from the filmed take, not an AI-drawn fake ticket as proof.

**Do not overclaim:** Checkout is test mode. Do not claim live paid orders or fulfilled shipments.

**Links:**
- [download](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/61)
- [checkout a](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/66)
- [checkout b](https://github.com/Jevelopers-neatHack-2026/getticketstub.com/pull/71)
- [org](https://github.com/Jevelopers-neatHack-2026)
- [checklist](https://github.com/Jevelopers-neatHack-2026/integration-evals/blob/main/planning/acceptance-checklist.json)

## Each required sponsor: five things the judges must see

| Sponsor | Architecture | Implementation | Runtime | Reasoning | Result |
|---|---|---|---|---|---|
| **neatlogs** | Allow-listed operational spans through OTLP/HTTP | getticketstub.com PR #46 | Real trace/screenshot | Where fetch failed, what model work followed | 6.9s success and distinct 8.0s timeout; **not** a before/after |
| **Entire** | Repo/graph/metadata and private git-refs checkpoint design | Versioned GitHub Actions entire-graph workflow | Ten exact-commit graph snapshots; one historical checkpoint | How graph/checkpoint informed change or review, if actually documented | Inspectable output; **not** universal live agent capture |
| **cfo.ai** | Separate planning model, not transaction truth | Inputs/forecast scenarios in the canvas | Live canvas and revision-2 native export | How price/cost/revenue/runway assumptions shape decisions | Excel-checked reviewer workbook; **hypothetical** numbers |

## Evidence and recording priorities

1. **Record the app first.** Capture a real event URL → research/result → design → exact PNG, including visible mode badges. If using the fixture demo, say so; do not disguise it as live third-party retrieval or AI generation.
2. **Record neatlogs UI.** Open a real success and the distinct timeout trace. Show trace IDs, durations, span hierarchy and implementation link. If the dashboard requires account access, use the preserved screenshots with provenance caveats.
3. **Record Entire UI/artifacts.** Open a verified GitHub Actions graph run and its saved snapshot, and a real historical checkpoint record. Do not show invented graph nodes as live capture.
4. **Record CFO.ai UI.** Open the actual canvas, change an assumption, inspect a forecast, then show the native reviewer export. Remove or conceal credentials/private account information.
5. **Recovery gap:** capture a controlled failure → next action → checked result in one new real run. Existing source does not establish comparable before/after improvement; omit claims or metrics if unrecorded.
6. **Building in public:** screen-record real public PRs/commits and use genuine #neatHack X post(s) if available. The public repositories alone do not prove social reach.
7. **Validate event code window.** Code must be written between Oct 10 **12:30 PM IST** and the confirmed Oct 12 deadline. Several repositories were created before the start; do not describe pre-window setup as code written during the hackathon.
8. **Test mode and acceptance:** label Dodo/Stripe as test-mode checkout, provider/fulfillment as scoped/offline where appropriate, and no finalized integrated product acceptance.
9. **Submission:** complete a public quote-post of the official neatlogs X submission post including team, project, public code repository and video link. Verify cutoff on Discord. Opening an X draft does not submit.

## Source and rights discipline

This package is a previsualization, not a source-approved public advertising asset and not a real-recorded product demo. Source repository marketing release checklist remains blocked pending real filmed footage, reviewer decisions, destination rights and submission approval. The vector screens are schematic, do not depict verified app UIs, and must be swapped for authentic captures before entry submission.

## Approval checklist (mark only with actual evidence)

- [ ] Final video length verified to be **≤180 seconds** (aim **170 seconds**).
- [ ] Visible demo mode and any sandbox checkout labeled; source event and product output authentic.
- [ ] Distinct five-part proof for **neatlogs**, **Entire**, **cfo.ai**; no fictitious partner dashboards.
- [ ] Actual failure response and next action visible, or recovery is explicitly qualified.
- [ ] Claim of measured improvement supported by same-scenario, comparable before/after trace pairs; otherwise omitted.
- [ ] Public commits within the hackathon code window and genuine #neatHack social evidence.
- [ ] Exact final video and screenshots have rights, privacy and brand owner approval.
- [ ] Video has legible captions and a publicly accessible link.
- [ ] Public repo, team/project name, official X quote-post and confirmed Discord deadline checked.
