# TicketStub | neatHack 2026 Judge-Aligned Video Kit

**Duration plan:** 2:50 (170s); hackathon limit 3:00. **Use:** produce the actual filmed submission video.

## Files

- `ticketstub_judges_cut_timeline.png` — high-resolution 16:9 overall illustrated timeline.
- `ticketstub_judges_cut_timeline.svg` — editable vector version.
- `frames/01_*.png` through `frames/10_*.png` — 1920×1080 illustrated shot references, plus matching editable SVGs.
- `storyboard_and_directors_notes.md` — actual capture instructions, source limitations, judge-weight map and verification checklist.
- `voiceover_script.md` — timecoded narration, adaptable to genuine recorded facts.
- `edit_timeline.csv` and `scene_manifest.json` — cut timing and timecode source-of-truth.
- `draft_subtitles.srt` — draft captions; adjust to actual voice take.
- `evidence_sources.csv` — links to original GitHub/organizer evidence.
- `ticketstub_judges_cut_animatic.mp4` — optional **silent schematic previsualization**, NOT eligible as the actual product demo.

## Important

1. The visuals are conceptual vector art. Replace app, neatlogs, Entire and cfo.ai sections with real screen recordings and show clear mode labels.
2. The partner footage must demonstrate architecture, implementation, runtime, reasoning and result **for each tool**.
3. The existing trace archive supports successful and failed runs but **not** an apples-to-apples before/after improvement. A recovery cut is a recording target, not a verified claim.
4. Checkout is test-only and v1 cross-repository acceptance is incomplete.
5. Before public submission, verify real footage, source/provenance/privacy rights, reviewer approval, and the organizer's official X post/cutoff on Discord.

Official rules: https://neatlogs.com/hackathon
GitHub: https://github.com/Jevelopers-neatHack-2026
